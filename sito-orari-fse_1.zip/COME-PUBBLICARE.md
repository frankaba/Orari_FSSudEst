# Pubblicare gli orari FSE su GitHub Pages

Questa cartella è il sito completo. Va caricata così com'è: non c'è niente da compilare,
niente dipendenze, niente build step.

```
sito/
  index.html            l'app (289 KB: dati, font e logica tutto dentro)
  manifest.webmanifest  la rende installabile come app
  sw.js                 service worker: la rende disponibile offline
  icona-180.png         icona per iPhone
  icona-192.png         icona per Android
  icona-512.png         icona grande + maskable
  .nojekyll             dice a GitHub di non processare i file
```

## Pubblicazione (5 minuti, dal browser, senza git)

1. Vai su **github.com/new**. Nome repository: `orari-fse`. Mettilo **Public**
   (GitHub Pages richiede repo pubblico sul piano gratuito). Crea.
2. Nella pagina del repo vuoto: **uploading an existing file**.
3. Trascina **tutti i file dentro `sito/`** (non la cartella: il contenuto).
   Il file `.nojekyll` è nascosto in alcuni sistemi: se non lo vedi, attiva la
   visualizzazione dei file nascosti, oppure creane uno vuoto con quel nome
   direttamente su GitHub (**Add file → Create new file**, nome `.nojekyll`, salva).
4. **Commit changes**.
5. **Settings → Pages**. In *Source* scegli **Deploy from a branch**,
   branch **main**, cartella **/ (root)**. Salva.
6. Dopo un paio di minuti l'indirizzo è:
   `https://TUONOME.github.io/orari-fse/`

## Sul telefono

Apri quell'indirizzo, poi:

- **Android / Chrome**: menu **⋮** → *Installa app* (o *Aggiungi a schermata Home*).
- **iPhone / Safari**: tasto **Condividi** → *Aggiungi a Home*.

Nasce un'icona come quella di qualsiasi app. Dopo la prima apertura il service worker
ha messo tutto in cache: **da quel momento funziona senza rete**, in galleria, in aereo,
con lo zero di campo.

## Quando esce il nuovo orario

```bash
python3 build_db.py nuovo_orario.pdf fse.db
python3 valida.py  nuovo_orario.pdf fse.db     # deve dare PASS
python3 gen_html.py fse.db sito/index.html
```

Poi, **importante**: apri `sito/sw.js` e cambia la riga

```js
const VERSIONE = "orari-fse-2026-07-06";
```

mettendo la nuova data di validità. Senza questo, i telefoni che hanno già installato
l'app continuano a servire la vecchia versione dalla cache e non vedono mai il nuovo
orario. Ricarica i file su GitHub e i telefoni si aggiornano da soli alla prima
apertura con rete.

## Note

- Il repo è pubblico, quindi l'orario è visibile a chiunque abbia il link. I dati vengono
  dal P.d.E. pubblico FSE, ma è un'elaborazione non ufficiale: se lo condividi fuori,
  dillo esplicitamente.
- L'app non fa nessuna chiamata di rete e non raccoglie nulla: font e dati sono
  incorporati in `index.html`.
- Se preferisci non usare GitHub, la stessa cartella funziona identica su Netlify Drop
  (netlify.com/drop: trascini la cartella, ottieni un URL) o Cloudflare Pages.
